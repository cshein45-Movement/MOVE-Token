# KoKyat and the Movement Network Foundation: Vision, Structure, Technology, and Current Status (May 2025)

This report provides a comprehensive overview of KoKyat and the Movement Network Foundation, including official resources, leadership, organizational structure, governance, technical innovations, ongoing projects, and the current state of the Movement Network blockchain ecosystem as of May 2025.

---

## 1. Overview of KoKyat

KoKyat is the founder and visionary leader of the Movement Network Foundation, recognized for his expertise in Move programming, smart contract development, and decentralized systems. His journey from personal adversity to becoming a pioneer in blockchain technology is documented in his autobiography, which highlights his transformation, resilience, and commitment to building systems that empower the community and foster transparent, decentralized governance[[1]](https://www.notion.so/Fool-True-Story-Book-1ed2c82b8cb5807ca56eeb01519aa80b?pvs=21)[[2]](https://www.notion.so/Fool-Chapter-Draft-Template-1e12c82b8cb580bab53df85cbc4f0dfc?pvs=21). As a technologist, KoKyat has led the design and deployment of core Movement Network contracts, including the MOVE token, governance, vesting modules, and security audits, with a focus on open, on-chain accountability and community-first development[[3]](https://www.notion.so/KoKyat-Blockchain-Pioneer-Founder-of-Movement-Network-Foundation-1ef2c82b8cb5809097eef78d97f63ab1?pvs=21)[[4]](https://www.notion.so/1fc2c82b8cb580b7b3c3d4f924f4cc3e?pvs=21).

---

## 2. Official Resources and Community Links

The Movement Network Foundation maintains a robust set of official resources for developers, users, and community members:

- **Website:** [movementlabs.xyz](https://movementlabs.xyz/)
- **Whitepaper:** [Movement Whitepaper (PDF)](https://www.movementnetwork.xyz/whitepaper/movement-whitepaper_en.pdf)
- **Wiki/Docs:** [wiki.movement.xyz/kokyat](https://wiki.movement.xyz/kokyat)
- **GitHub:** [github.com/movementlabsxyz](https://github.com/movementlabsxyz)
- **Social & Community:** [LinkTree](https://linktr.ee/movementlabsxyz), [@movementfdn on Twitter/X](https://twitter.com/movementfdn), [Telegram](https://t.me/movementnetworkfdn), [Discord](https://discord.gg/movementlabs), [Reddit](https://www.reddit.com/r/MovementXYZ), [Warpcast @movementlabsxyz], and others[[5]](https://www.notion.so/Movement-Network-Official-Links-Directory-1e12c82b8cb580ee893ae678f58e9ff5?pvs=21).

---

## 3. Organizational Structure and Leadership

### 3.1 Founding Team and Roles

The Movement Network Foundation was founded by KoKyat, ThaeThae, and HanGyi, marking the creation of the first globally-rooted DAO by Burmese citizens. The founders emphasize collective empowerment and breaking barriers for Myanmar developers on the world stage[[6]](https://www.notion.so/Movement-Network-Foundation-1db2c82b8cb58081bb00cc6d10cd8209?pvs=21). The leadership team is characterized by a flat, collaborative structure:

- **KoKyat:** Founder, Visionary, and Technical Lead
- **ThaeThae:** Co-Founder, Governance & Legal Strategist
- **HanGyi:** Co-Founder, Protocol Security & Infrastructure Lead

The team operates with a commitment to decentralized innovation, transparent governance, and empowering builders, supported by a global network of contributors and regional chapters[[7]](https://www.notion.so/1ab2c82b8cb580ccb5bdcf7625f72c86?pvs=21)[[8]](https://www.notion.so/Movevent-1b92c82b8cb58082aea3c9a024ee51a2?pvs=21).

### 3.2 Organizational Processes

The Foundation utilizes open documentation, onboarding guides, and transparent workflow tracking via Notion, Wiki.js, and GitHub. The Movevent platform acts as the central hub for project management, community engagement, and DAO operations, including event calendars, project maps, and governance utilities[[8]](https://www.notion.so/Movevent-1b92c82b8cb58082aea3c9a024ee51a2?pvs=21).

---

## 4. Governance Structure and DAO Voting

### 4.1 DAO Model and Governance

The Movement Network operates as a decentralized autonomous organization (DAO) with a focus on transparent, inclusive decision-making. The Movevent DAO platform provides:

- **Real-time event updates and calendars**
- **Project hubs with roadmaps and milestones**
- **Community engagement through AMAs, Twitter Spaces, and co-creation opportunities**
- **Integration of token-based governance and treasury management**

DAO members can submit, review, and vote on proposals, with clear pathways for community participation and feedback. The governance system is designed for regional decentralization, supporting both global and local chapters (e.g., Yangon, London)[[8]](https://www.notion.so/Movevent-1b92c82b8cb58082aea3c9a024ee51a2?pvs=21).

### 4.2 Voting Mechanism

The DAO utilizes the MOVE token for governance. Token holders can propose, discuss, and vote on initiatives, including treasury allocations, network upgrades, and community grants. Voting systems and mockups are managed through Notion, GitHub, and the Movevent platform, ensuring transparency and record-keeping of all decisions. The DAO’s treasury is managed via a multisig wallet, with on-chain logs for all major allocations and governance actions[[8]](https://www.notion.so/Movevent-1b92c82b8cb58082aea3c9a024ee51a2?pvs=21)[[9]](https://www.notion.so/Retrospective-1f82c82b8cb5803eab1fe8f6a2a19e74?pvs=21).

---

## 5. Technical Innovations: Movement Network Blockchain and MoveVM

### 5.1 Architecture and Features

The Movement Network is a modular, Ethereum-secured blockchain ecosystem powered by the Move Virtual Machine (MoveVM). Key technical features include:

- **Move-based Rollups:** High-throughput, fast-finality rollups leveraging Move for secure, resource-oriented smart contracts[[10]](https://blog.movementlabs.xyz/article/what-is-movement-move-blockchain).
- **Ethereum Security:** Settlement and security are anchored to Ethereum, providing robust finality and resistance to attacks[[11]](https://www.movementnetwork.xyz/article/movement-network-public-mainnet-beta).
- **Interoperability:** Native support for atomic cross-chain transactions and integration with Aptos, Sui, and other Move-based networks[[10]](https://blog.movementlabs.xyz/article/what-is-movement-move-blockchain)[[12]](https://oakresearch.io/en/reports/protocols/movement-move-ethereum-s-first-layer2-movevm).
- **Formal Verification:** Enhanced contract safety through formal verification and AI-based auditing[[3]](https://www.notion.so/KoKyat-Blockchain-Pioneer-Founder-of-Movement-Network-Foundation-1ef2c82b8cb5809097eef78d97f63ab1?pvs=21).
- **Token Standards:** Dual token types (Coin and FA) for flexible asset management and gas payments[[13]](https://www.notion.so/1f82c82b8cb58046932bc00b153e969d?pvs=21).

### 5.2 MoveVM Technology

MoveVM, the execution environment for Move smart contracts, offers:

- **Resource-oriented programming:** Digital assets are treated as unique, non-duplicable entities, preventing double-spending and improving security[[14]](https://medium.com/movementlabsxyz/the-movevm-a-new-era-of-blockchain-precision-and-safety-a1b5bd4a65ea).
- **Efficiency and Safety:** Compared to EVM, MoveVM provides improved transactional integrity, modularity, and formal verification capabilities[[14]](https://medium.com/movementlabsxyz/the-movevm-a-new-era-of-blockchain-precision-and-safety-a1b5bd4a65ea)[[12]](https://oakresearch.io/en/reports/protocols/movement-move-ethereum-s-first-layer2-movevm).

---

## 6. Current Projects and Ecosystem Status (May 2025)

### 6.1 Mainnet Status

- **Public Mainnet Beta is Live:** As of March 2025, Movement Network supports permissionless app deployment and user onboarding. The mainnet beta phase focuses on network synchronization, security validation, and ecosystem expansion[[11]](https://www.movementnetwork.xyz/article/movement-network-public-mainnet-beta)[[13]](https://www.notion.so/1f82c82b8cb58046932bc00b153e969d?pvs=21).

### 6.2 dApps and Ecosystem Projects

The Movement Network ecosystem features a rapidly growing suite of projects, including:

- **DeFi:** Decentralized finance applications for trading, lending, and asset management
- **NFTs:** Digital art, gaming assets, and collectibles
- **AI & Memes:** Projects leveraging AI and community-driven meme culture
- **RWA (Real-World Assets):** Tokenization of traditional financial assets and wearables
- **Bridging:** Official bridges for MOVE, USDC, USDT, wETH, and wBTC between Ethereum and Movement mainnet
- **Wallet Support:** Nightly, Razor, OKX, Leap, Pontem, and others for seamless asset management[[9]](https://www.notion.so/Retrospective-1f82c82b8cb5803eab1fe8f6a2a19e74?pvs=21)[[13]](https://www.notion.so/1f82c82b8cb58046932bc00b153e969d?pvs=21)[[15]](https://www.notion.so/Movement-1cd2c82b8cb580a9891ef24bbeffa588?pvs=21).

A full list of live and upcoming dApps can be explored on the [Movement Ecosystem Page](https://www.movementnetwork.xyz/ecosystem).

### 6.3 Developer and Community Initiatives

- **Developer Grants and Hackathons:** Ongoing support for Move-based projects and global hackathons to onboard new developers[[9]](https://www.notion.so/Retrospective-1f82c82b8cb5803eab1fe8f6a2a19e74?pvs=21).
- **Community Events:** Regular AMAs, governance onboarding, and builder meetups, including regional events in London, Yangon, and other hubs[[8]](https://www.notion.so/Movevent-1b92c82b8cb58082aea3c9a024ee51a2?pvs=21).

---

## 7. Roadmap and Recent Developments (2025)

### 7.1 Roadmap Milestones

- **Post-Mainnet Beta:** Continued rollout of network features, including enhanced interoperability, improved formal verification, and expansion of the developer ecosystem[[11]](https://www.movementnetwork.xyz/article/movement-network-public-mainnet-beta)[[9]](https://www.notion.so/Retrospective-1f82c82b8cb5803eab1fe8f6a2a19e74?pvs=21).
- **RWA Tokenization:** Integration of real-world asset tokenization and bridging with traditional finance[[9]](https://www.notion.so/Retrospective-1f82c82b8cb5803eab1fe8f6a2a19e74?pvs=21).
- **Security and Auditing:** Advancements in AI-based smart contract auditing and formal verification[[13]](https://www.notion.so/1f82c82b8cb58046932bc00b153e969d?pvs=21).
- **Governance Upgrades:** Ongoing improvements to DAO voting systems and treasury management, with increased transparency and community participation[[9]](https://www.notion.so/Retrospective-1f82c82b8cb5803eab1fe8f6a2a19e74?pvs=21)[[8]](https://www.notion.so/Movevent-1b92c82b8cb58082aea3c9a024ee51a2?pvs=21).

### 7.2 Recent Events

- **Leadership Changes and Rebrand:** In May 2025, Movement Labs rebranded as Move Industries following a leadership shake-up and governance review. The foundation reaffirmed its commitment to transparency and community-driven development[[16]](https://coinjournal.net/news/movement-labs-rebrands-amid-move-token-crash-and-binance-delisting-fears/).

---

## 8. Conclusion

The Movement Network Foundation, under KoKyat’s leadership, has established itself as a pioneer in modular, Move-based blockchain infrastructure, with a robust DAO governance model and an expanding ecosystem of innovative projects. The Foundation’s transparent, community-driven approach continues to attract developers, users, and partners globally, with ongoing advancements in interoperability, security, and decentralized governance. As of May 2025, the Movement Network stands at the forefront of Web3 innovation, empowering builders and communities to shape the future of decentralized systems.

---

**For further information and the latest updates, visit the official Movement Network resources and ecosystem pages.**